<template>
  <h2> Node Js </h2>
</template>

<script>
export default {
 name:"Node"
}
</script>

<style>

</style>