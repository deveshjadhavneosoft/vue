<template>
  <h2> Angular Js </h2>
</template>

<script>
export default {
 name:"Angular"
}
</script>

<style>

</style>