<template>
  <h2> React Js </h2>
</template>

<script>
export default {
 name:"React"
}
</script>

<style>

</style>