<template>
  <h2> MainCourse </h2>
</template>

<script>
export default {
 name:"MainCourse"
}
</script>

<style>

</style>